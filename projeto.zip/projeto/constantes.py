import os
import pygame 
from caminhos import FONTS_DIR

#Atributos
VELOCIDADE = 4

#Cores
BRANCO = (255, 255, 255)
PRETO = (0, 0, 0)
VERMELHO = (200, 0, 0)
LARANJA = (255, 165, 0)
AZUL = (0, 0, 255)
CIANO = (65, 220, 205)

#Medidas da tela
LARGURA = 1000
ALTURA = 600

#Medidas especiais
TILE_SIZE = 48
OFFSET = 40

#Pedidos
TEMPOFACIL = 30
PONTUACAOFACIL = 10

TEMPOMEDIO = 45
PONTUACAOMEDIO = 15

TEMPODIFICIL = 50
PONTUACAODIFICIL = 20

#Fases
TEMPOINICIAL = 60

#Seleção 
MARGEM = 3
TAMANHO = 7
ESPESSURA = 3
