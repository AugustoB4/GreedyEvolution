import apoio
import unittest

from itens import Alface, Carne, Pao, Queijo, Tomate
from montagem import Montagem
from pedido import PedidoDificil, PedidoFacil, PedidoMedio


CLASSES_INGREDIENTES = {
    "Pão": Pao,
    "Queijo": Queijo,
    "Carne": Carne,
    "Tomate": Tomate,
    "Alface": Alface,
}


def criar_montagem(pedido, nomes=None, carne_assada=True, carne_queimada=False):
    montagem = Montagem(0, 0, pedido)
    nomes = nomes or pedido.ingredientes

    for nome in nomes:
        ingrediente = CLASSES_INGREDIENTES[nome](0, 0)
        if ingrediente.nome == "Meat":
            ingrediente.assado = carne_assada
            ingrediente.queimado = carne_queimada
            ingrediente.cru = not carne_assada
        else:
            ingrediente.cortado = True
        montagem.adicionar_ingrediente(ingrediente, "1")

    return montagem


class TestMontagem(unittest.TestCase):
    def test_receitas_de_hamburguer_atuais_ficam_prontas(self):
        receitas = (
            (PedidoFacil, False, False),
            (PedidoMedio, True, False),
            (PedidoDificil, True, True),
        )

        for classe_pedido, com_tomate, com_alface in receitas:
            with self.subTest(pedido=classe_pedido.__name__):
                pedido = classe_pedido()
                montagem = criar_montagem(pedido)

                self.assertTrue(montagem.hamburguer_pronto)
                hamburguer = montagem.pegar_ingrediente()
                self.assertEqual(hamburguer.nome, "Hamburguer")
                self.assertEqual(hamburguer.com_tomate, com_tomate)
                self.assertEqual(hamburguer.com_alface, com_alface)

    def test_receita_na_ordem_errada_nao_fica_pronta(self):
        pedido = PedidoFacil()
        ordem_errada = ["Queijo", "Pão", "Carne"]

        montagem = criar_montagem(pedido, nomes=ordem_errada)

        self.assertFalse(montagem.hamburguer_pronto)

    def test_carne_crua_impede_concluir_a_receita(self):
        montagem = criar_montagem(PedidoFacil(), carne_assada=False)

        self.assertFalse(montagem.hamburguer_pronto)

    def test_carne_queimada_impede_concluir_a_receita(self):
        montagem = criar_montagem(
            PedidoFacil(), carne_assada=False, carne_queimada=True
        )

        self.assertFalse(montagem.hamburguer_pronto)


if __name__ == "__main__":
    unittest.main()
