import os

BASE_DIR = os.path.dirname(
    os.path.abspath(__file__)
)
BASE_FS = os.path.dirname(
    os.path.abspath(__file__)
)
BASE_BT = os.path.dirname(
    os.path.abspath(__file__)
)
BASE_PG = os.path.dirname(
    os.path.abspath(__file__)
)
BASE_CT = os.path.dirname(
    os.path.abspath(__file__)
)
BASE_AD = os.path.dirname(
    os.path.abspath(__file__)
)
BASE_FN = os.path.dirname(
    os.path.abspath(__file__)
)
BASE_ST = os.path.dirname(
    os.path.abspath(__file__)
)



ASSETS_DIR = os.path.join(
    BASE_DIR, "assets"
)

SPRITES_DIR = os.path.join(
    BASE_DIR, "assets", "sprites"
)

BACKGROUND_DIR = os.path.join(
    SPRITES_DIR, "background"
)

ANIMATION_DIR = os.path.join(
    SPRITES_DIR, "animations"
)

PINS_DIR = os.path.join(
    SPRITES_DIR, "pins"
)


INGREDIENTS_DIR = os.path.join(
    SPRITES_DIR, "ingredients"
)

PLAYER_DIR = os.path.join(
    SPRITES_DIR, "player"
)

TILES_DIR = os.path.join(
    SPRITES_DIR, "tiles"
)

UI_DIR = os.path.join(
    SPRITES_DIR, "ui"
)

FASES_DIR = os.path.join(
    SPRITES_DIR, "fases"
)

TUTORIALS_DIR = os.path.join(
    SPRITES_DIR, "tutorials"
)

FONTS_DIR = os.path.join(
    ASSETS_DIR, "fonts"
)

ORDERS_DIR = os.path.join(
    SPRITES_DIR, "orders"
)

SOUNDS_DIR = os.path.join(
    BASE_DIR, "assets", "sounds"
)
SOUNDS_FS = os.path.join(
    BASE_FS, "assets", "sounds"
)
SOUNDS_BT = os.path.join(
    BASE_BT, "assets", "sounds"

)
SOUNDS_PG = os.path.join(
    BASE_PG, "assets", "sounds"
)
SOUNDS_CT = os.path.join(
    BASE_CT, "assets", "sounds"
)
SOUNDS_AD = os.path.join(
    BASE_AD, "assets", "sounds"
)
SOUNDS_FN = os.path.join(
    BASE_FN, "assets", "sounds"
)
SOUNDS_ST = os.path.join(
    BASE_ST, "assets", "sounds"
)

def tiles_dir_estilo(estilo="classico"):
    if estilo == "classico":
        return TILES_DIR
    return os.path.join(TILES_DIR, estilo)


def pins_dir_estilo(estilo="classico"):
    if estilo == "classico":
        return PINS_DIR
    return os.path.join(PINS_DIR, estilo)
