import os
import pygame

from constantes import TILE_SIZE
from caminhos import TILES_DIR
from caminhos import SOUNDS_DIR, SOUNDS_FS, SOUNDS_BT
from itens import *


MAPA = [
    "WYIIIIIIIIIIIIIIIIIYW",
    "W1S2B22332122O22B2R1W",
    "W1FFFFFFFF1FFFFFFFF1W",
    "W1FF1111FF2FF1111FFNM",
    "W1FF2332FFFFF2LT2FF1W",
    "W1FFFFFFFFFFFFFFFFF1W",
    "W1FFFFFFFF1FFFFFFFF1W",
    "W1FF1111FF2FF1111FF1W",
    "W1FF2LT2FFFFF4332FF1W",
    "W1FFFFFFFFFFFFFFFFF1W",
    "W1FFFFFFFF1FFFFFFFF1W",
    "W1111111111111111111W",
    "WWWWWWWWWWWWWWWWWWWWW",
]

"W = Wall / Parede"
"F = Floor / Chão"
"1 = 1Counter / Bancada de trás"
"2 = 2Counter / Primeira bancada de frente"
"3 = 3Counter / Segunda bancada de frente (com armários)"
"4 = CounterCheese / Segunda bancada de frente (com queijo)"
"S = Sink / Pia"
"O = Oven / Fogão"
"B = CuttingBoard / Tábua de corte"
"Y = RightWindow / Janela da direita"
"I = MiddleWindow / Janela do meio"
"T = TreadMill / Esteira de velocidade"
"N = DeliveryBelt / Esteira de Delivery"
"M = DeliveryWindow / Janela de Delivery"
"R = Refrigerator / Geladeira"


class Tabua:
    def __init__(self, x, y):
        self.posX = x
        self.posY = y

        self.rect = pygame.Rect(self.posX, self.posY, 32, 32)
        
class Forno:
    def __init__(self, x, y):
        self.posX = x
        self.posY = y
        
        self.rect = pygame.Rect(self.posX, self.posY, 32, 32)

class Armario:
    def __init__(self, x, y):
        self.posX = x
        self.posY = y
        self.ingrediente = None

        self.rect = pygame.Rect(self.posX, self.posY, 32, 32)

class ArmarioQueijo:
    def __init__(self, x, y):
        self.posX = x
        self.posY = y
        self.ingrediente = None

        self.rect = pygame.Rect(self.posX, self.posY, 32, 32)
class ArmarioTomate:
    def __init__(self, x, y):
        self.posX = x
        self.posY = y
        self.ingrediente = None

        self.rect = pygame.Rect(self.posX, self.posY, 32, 32)
        
class ArmarioAlface:
    def __init__(self, x, y):
        self.posX = x
        self.posY = y
        self.ingrediente = None

        self.rect = pygame.Rect(self.posX, self.posY, 32, 32)
        
class Geladeira:
    def __init__(self, x, y):
        self.posX = x
        self.posY = y
        self.ingrediente = None

        self.rect = pygame.Rect(self.posX, self.posY, 32, 32)

class Mapa:
    def __init__(self):
        self.tabuas = []
        self.armarios = []
        self.armarios_tomate = []
        self.armarios_alface = []
        self.armarios_queijo = []
        self.geladeiras = []
        self.colisoes = []
        self.tiles = {

            'F': pygame.image.load(os.path.join(TILES_DIR, "Floor.png")).convert_alpha(),
            'W': pygame.image.load(os.path.join(TILES_DIR, "Wall.png")).convert_alpha(),
            'M': pygame.image.load(os.path.join(TILES_DIR, "DeliveryWindow2.png")).convert_alpha(),
            'N': pygame.image.load(os.path.join(TILES_DIR, "DeliveryBelt.png")).convert_alpha(),
            '1': pygame.image.load(os.path.join(TILES_DIR, "CounterUp.png")).convert_alpha(),
            '2': pygame.image.load(os.path.join(TILES_DIR, "CounterFront.png")).convert_alpha(),
            '3': pygame.image.load(os.path.join(TILES_DIR, "CounterFront2.png")).convert_alpha(),
            '4': pygame.image.load(os.path.join(TILES_DIR, "CounterCheese.png")).convert_alpha(),
            'S': pygame.image.load(os.path.join(TILES_DIR, "Sink.png")).convert_alpha(),
            'B': pygame.image.load(os.path.join(TILES_DIR, "CuttingBoard.png")).convert_alpha(),
            'Y': pygame.image.load(os.path.join(TILES_DIR, "RightWindow.png")).convert_alpha(),
            'I': pygame.image.load(os.path.join(TILES_DIR, "MiddleWindow.png")).convert_alpha(),
            '@': pygame.image.load(os.path.join(TILES_DIR, "TreadMill.png")).convert_alpha(),
            'O': pygame.image.load(os.path.join(TILES_DIR, "Oven.png")).convert_alpha(),
            'R': pygame.image.load(os.path.join(TILES_DIR, "Refrigerator.png")).convert_alpha(),
            'L': pygame.image.load(os.path.join(TILES_DIR, "LettuceDispenser.png")).convert_alpha(),
            'T': pygame.image.load(os.path.join(TILES_DIR, "TomatoDispenser.png")).convert_alpha()
        }

    def desenhar(self, tela):
        for linha, caractere in enumerate(MAPA):
            for coluna, letra in enumerate(caractere):
                sprite = self.tiles[letra]
                if letra == "Y" and coluna == 19:
                    sprite = pygame.transform.flip(sprite, True, False) # Virar os tiles em qualquer direção
                    
                if letra == "M" and coluna == 20:
                    sprite = pygame.transform.rotate(sprite, -90) # ROtaciona a imagem em graus
                    
                if letra == "R":
                    sprite = pygame.transform.scale(self.tiles["R"], (TILE_SIZE, TILE_SIZE * 2))
                    tela.blit(sprite,(coluna * TILE_SIZE, linha * TILE_SIZE - TILE_SIZE))
                    continue

                tela.blit(sprite,(coluna * TILE_SIZE, linha * TILE_SIZE))

        # os tomates dentro do armário ficam ocultos até o clique de pegar

    def criar_colisoes(self):
        self.colisoes.clear()
        self.tabuas.clear()
        self.armarios.clear()
        self.armarios_tomate.clear()
        self.armarios_queijo.clear()
        self.geladeiras.clear()
        
        
        for linha, texto in enumerate(MAPA):
            for coluna, letra in enumerate(texto):
                if letra in ("1", "2", "3", "4", "B", "C", "W", "S", "M", "O", "N", "R", "L", "T"): # Adiciona colisão ao tile
                    self.colisoes.append(
                        pygame.Rect(
                            coluna * TILE_SIZE,
                            linha * TILE_SIZE,
                            TILE_SIZE,
                            TILE_SIZE
                        )
                    )

                if letra == "B":
                    x = coluna * TILE_SIZE
                    y = linha * TILE_SIZE
                    self.tabuas.append(Tabua(x, y))

                if letra == "3":
                    x = coluna * TILE_SIZE
                    y = linha * TILE_SIZE
                    armario = Armario(x, y)
                    armario.ingrediente = Pao(x, y)
                    self.armarios.append(armario)

                if letra == "T":
                    x = coluna * TILE_SIZE
                    y = linha * TILE_SIZE
                    armario_tomate = ArmarioTomate(x, y)
                    armario_tomate.ingrediente = Tomate(x, y)
                    self.armarios_tomate.append(armario_tomate)
                
                if letra == "L":
                    x = coluna * TILE_SIZE
                    y = linha * TILE_SIZE
                    armario_alface = ArmarioAlface(x, y)
                    armario_alface.ingrediente = Alface(x, y)
                    self.armarios_alface.append(armario_alface)

                if letra == "4":
                    x = coluna * TILE_SIZE
                    y = linha * TILE_SIZE
                    armario_queijo = ArmarioQueijo(x, y)
                    armario_queijo.ingrediente = Queijo(x, y)
                    self.armarios_queijo.append(armario_queijo)
                    
                if letra == "R":
                    x = coluna * TILE_SIZE
                    y = linha * TILE_SIZE
                    geladeira = Geladeira(x, y)
                    geladeira.ingrediente = Carne(x, y)
                    self.geladeiras.append(geladeira)

    def pode_largar(self, x, y):
        coluna = x // TILE_SIZE
        linha = y // TILE_SIZE

        if linha < 0 or linha >= len(MAPA):
            return False

        if coluna < 0 or coluna >= len(MAPA[linha]):
            return False

        return MAPA[linha][coluna] in ("F", "B")

