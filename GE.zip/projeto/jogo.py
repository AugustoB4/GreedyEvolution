import pygame

from constantes import *
from menu import Menu
from player import Romerio, Brito, tomates, queijos, paos, carnes, alfaces
from itens import *
from mapa import Mapa

from sons import som_inicial, som_face
from caminhos import BACKGROUND_DIR

class Jogo:
    def __init__(self):
        pygame.init()

        self.largura = int(LARGURA)
        self.altura = int(ALTURA)

        self.tela = pygame.display.set_mode(
            (self.largura, self.altura)
        )

        pygame.display.set_caption("Greedy Evolution")

        som_inicial.play()

        self.mapa1 = Mapa()
        self.mapa1.criar_colisoes()
        self.armarios = self.mapa1.armarios
        self.armarios_queijo = self.mapa1.armarios_queijo
        self.armarios_tomate = self.mapa1.armarios_tomate
        self.armarios_alface = self.mapa1.armarios_alface
        self.geladeiras = self.mapa1.geladeiras

        self.background = pygame.image.load(
            os.path.join(
                BACKGROUND_DIR,
                "StartMenuBG.png"
            )
        ).convert()

        self.background = pygame.transform.scale(
            self.background,
            (self.largura, self.altura)
        )
        self.tomates = tomates
        self.queijos = queijos
        self.paos = paos
        self.carnes = carnes
        self.alfaces = alfaces


        self.player1 = Romerio(750, 200)
        self.player2 = Brito(250, 200)

        self.rodando = True
        self.clock = pygame.time.Clock()

    def verificarEventos(self):
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                self.rodando = False

            self.player1.verificar_habilidades(evento, self.armarios, self.armarios_queijo,self.armarios_tomate, self.armarios_alface,self.tomates, self.alfaces, self.queijos,self.paos, self.carnes)
            self.player2.verificar_habilidades(evento, self.armarios, self.armarios_queijo,self.armarios_tomate, self.armarios_alface,self.tomates, self.alfaces, self.queijos, self.paos, self.carnes)

            self.player1.verificar_cortagem(evento, self.mapa1.tabuas, self.tomates, self.queijos, self.paos)
            self.player2.verificar_cortagem(evento, self.mapa1.tabuas, self.tomates, self.queijos, self.paos)

        self.player1.mover(self.mapa1.colisoes)
        self.player2.mover(self.mapa1.colisoes)

        for tomate in self.tomates:
            tomate.atualizar()
        for queijo in self.queijos:
            queijo.atualizar()
        for pao in self.paos:
            pao.atualizar()
        for carne in self.carnes:
            carne.atualizar()

    def desenhar(self):
        self.tela.fill(PRETO)
        self.mapa1.desenhar(self.tela)

        self.player1.desenhar(self.tela)
        self.player2.desenhar(self.tela)

        for tomate in self.tomates:
            tomate.desenhar(self.tela)
        for queijo in self.queijos:
            queijo.desenhar(self.tela)
        for pao in self.paos:
            pao.desenhar(self.tela)
        for carne in self.carnes:
            carne.desenhar(self.tela)

        pygame.display.flip()

    def iniciar(self):
        menu = Menu(self.tela, self.largura, self.altura)
        if not menu.executar():
            self.rodando = False
        else:
            som_inicial.stop()
            som_face.play(-1)
           
        while self.rodando == True:
            self.verificarEventos()
            self.desenhar()
            self.clock.tick(60)
        pygame.quit()